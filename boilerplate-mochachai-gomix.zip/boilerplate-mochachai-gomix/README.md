FCC Test Challenge Prototype 
============================
[![Run on Repl.it](https://repl.it/badge/github/freeCodeCamp/boilerplate-mochachai)](https://repl.it/github/freeCodeCamp/boilerplate-mochachai)

QA with mocha & chai
